<?php
return[
    'seo'=>'Seo',
    'seometa'=>'meat Tags'  ,
    'scripthead'=>'Script In Head',
    'scriptfooter'=>'Script In Footer',
    'addseo'=>'Add Seo',
    'Updateseo'=>'Update Seo',
     'titlear'=> ' Add Seo title_AR',
    'titleeng'=>'Add Seo title_en',
    'desceng' => 'Add  Seo description_en',
    'descar' => 'Add Seo description_AR',
    'keywordar'=>'Add  Seo keyword_AR',
    'keywordeng'=>'Add Seo keyword_en'

];
