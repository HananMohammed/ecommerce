<?php
return[
    "admin"=>"Admin Management",
    'name' => 'Name',
    'email'=>'Email',
    'action'=>'Actions ',
    'role'=>'Roles',
    'edit'=>'Edit',
    'delete'=>'Delete ',
]
?>
