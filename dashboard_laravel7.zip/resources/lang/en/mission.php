<?php
return[
     'mission'=>'Mission And Vission',
     'missionAr'=>'Mission in Arabic'  ,
     'missionEn'=>'Mission in English',
     'vissionAr'=>'Vission in Arabic'  ,
     'vissionEn'=>'Vission in English',
     'add'=>'Add ',
     'Update'=>'Update '  ,
    'missionw'=>'Mission',
    'vision'=>'our vision',
    'value'=>'our value',
    'readmore'=>'Read more'


];
