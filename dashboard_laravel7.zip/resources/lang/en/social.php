<?php
return[
    'social'=>'Social',
    'allsocial'=>'All Social ',
    'addsocial'=>'Add Social',
    'icon'=>'Select Icon ',
    'link'=>'link',
];
