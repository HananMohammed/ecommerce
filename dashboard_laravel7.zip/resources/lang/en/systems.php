<?php
return[
    'lang'=>'en',
    'lang2'=>'eng',
  'langval'=>'عربى ',
    'sub'=>'subscribe'
];