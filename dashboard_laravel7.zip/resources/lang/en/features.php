<?php
return[
    'feature'=>'Features',
    'feature_en'=>'Feature_en',
    'feature_ar'=>'Feature_ar',
    'addfeature'=>' Add Features',
    'singleft'=>'The advantages of buying from the attractive car'

]
?>