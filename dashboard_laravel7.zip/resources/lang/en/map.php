<?php
return[
    'addmap'=>' Add Map',
    'name'=>'Map Name',
    'link'=>'Map Link',
    'delete'=>'Delete'

]
?>