<?php
return[
    'edit'=>'Edit',
    'delete'=>'Delete',
    'createdBy'=>'Created By',
    'createdTime'=>'Created Time',
];