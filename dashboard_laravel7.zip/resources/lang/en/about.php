<?php
return[
    'about'=>'About Us',
    'aboutAr'=>'About Us in arabic'  ,
    'aboutEn'=>'About Us in English',
    'addAbout'=>'Add About Us',
    'UpdateAbout'=>'Update About Us',
    'abouthome'=>'ABOUT ',
    //single page about us and service section at home page
    'attractive'=>'attractive',
    'advantages'=>'The advantages of buying from the attractive car',
    'washing'=>'car washing',
    'taxi'=>'Taxi service and customer transportation',
    'workshop'=>'Join the loyalty program',
    'door'=>'open cars door',
    'tire'=>'Tire switch',
    'discount'=>'Discounts up to 50%',
    'edges'=>'protect edges of the door',
    'battery'=>'battery subscription',
    'pull'=>'pull the car',
    'refueling'=>'refueling',
    'more'=>'Read More',
    'contact'=>'contact us',
    'book'=>'book your car now',
    'touch'=>"contact us and we'll be in touch soon",
    'book'=>'book your car now',

];
