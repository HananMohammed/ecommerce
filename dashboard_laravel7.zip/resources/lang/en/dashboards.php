<?php
return [
    'title'=>'Dashboard',
    'setting'=>'Setting',
    'addAdmin'=>'Add Admin',
    'homePage'=>'Home Page',
    'slider'=>'slider',
    'contactUs'=>'Contact Us',
    'removeadmin'=>'Admin Management',
    'emailuser'=>'Add User TO Email Response'
];
