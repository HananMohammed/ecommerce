<?php
return[
    'project'=>'Akwan Projects',
    'allproject' =>'All Projects ',
    'addproject' =>'Add Project',
    'proj_name_en' =>'Project Name_en',
    'proj_name_ar' =>'Project Name_ar',
    'images' =>'Upload Images',
    'name_en'=>'Category name_en',
    'name_ar'=>'Category name_ar',
    'link'=>'Link',
     'category'=>'Category',
    /*all projects page*/
    'projects'=>'Projects',
    'latest'=>'Latest',
    'social'=>'Social Media',
    'web'=>'Web Development',
    'mobil'=>'Mobil Apps',
    'videos'=>'Videos',
    'Identity'=>'Identity Corporation',
    'selectCat'=>'Select Category',

]
?>
