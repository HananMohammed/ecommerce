
<?php
return [
    'home' =>'Dashboard Home page',
    'lang' =>' عربي',
    'langval' =>'ar',
];
?>
