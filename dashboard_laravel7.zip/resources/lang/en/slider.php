<?php
return [
    'slide'=>'Slide',
    'addSlide'=>'Add Slid',
    'allSlides'=>'All Slides',
    'title'=>'Title',
    'title_en'=>'Title In English',
    'title_ar'=>'Title In Arabic',
    'description_en'=>'Description In English',
    'description_ar'=>'Description In Arabic',
    'alt'=>'Image description',


];