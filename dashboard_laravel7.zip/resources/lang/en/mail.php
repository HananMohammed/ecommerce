<?php
return[
    'mail'=>'Mail',
    'allMail'=>'All Mails ',
    'addMail'=>'Add Mail',
    'indvTo'=>'Individual Mail To',
    'indvCC'=>'Individual Mail cc',
    'comTo'=>'Company Mail To',
    'comCC'=>'Company Mail cc',
    'govTo'=>'government Mail To',
    'govCC'=>'government Mail cc',
    'nindTo'=>'request car Mail To',
    'nindCC'=>'request car Mail cc',
    'conTo'=>'contact us Mail To',
    'conCC'=>'contact us Mail cc',

];
