<?php
return[
  'title'=>'Analytics Dashboard',
  'subscribe'=>'All Mail Subscriber',
  'mails'=>'Email',
  'croups'=>'Number Of Products',
  'news'=>'Number Of News',
  'subscribers'=>'Number Of subscribers',
   'name'=>'Admins Name',
    'role'=>'Admins Role'
];
