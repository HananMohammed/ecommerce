<?php
return[
    'phone'=>'Phone Number',
    'allPhone'=>'All Phone Number',
    'addPhone'=>'Add Phone',
];
