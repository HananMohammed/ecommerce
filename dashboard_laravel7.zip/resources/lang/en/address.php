<?php
return[
    'address_en'=>'address In English',
    'address_ar'=>'address In Arabic',
    'allAddress'=>'All Address  ',
    'addAddress'=>'Add Address',
    'address'=>'Location',
    'subscribe'=>'Subscribe To Our Newsletter',
];
