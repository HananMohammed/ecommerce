<?php
return[
    'address_en'=>'العنوان بالأنجليزيه',
    'address_ar'=>'العنوان بالعربيه',
    'allAddress'=>'كل العناوين ',
    'addAddress'=>'أضافه عنوان',
    'address'=>'العنوان',
    'subscribe'=>'اشترك في نشرتنا الإخبارية',
];
