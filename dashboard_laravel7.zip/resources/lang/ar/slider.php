<?php
return [
    'slide'=>'شريحه',
    'addSlide'=>'اضافه صوره',
    'allSlides'=>'جميع الشرائح',
    'title'=>'عنوان',
    'title_en'=>'العنوان بالانجليزيه',
    'title_ar'=>'العنوان بالعربيه',
    'description_en'=>'ملخص بالانجليزيه',
    'description_ar'=>'ملخص بالعربيه',
    'alt'=>'وصف الصوره',

];