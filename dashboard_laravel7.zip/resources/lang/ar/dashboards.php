<?php
return [
    'title'=>'لوحه التحكم',
    'setting'=>'الضبط',
    'addAdmin'=>'أضافه مشرف',
    'homePage'=>'الصفحه الرئيسيه',
    'slider'=>'معرض الصور',
    'contactUs'=>'معلومات التواصل ',
    'removeadmin'=>'اداره المشرفين',
    'emailuser'=>'اضافه مستقبلين للبريد الالكترونى'
];
