
<?php
return [
'home' =>' الصفحه الرئيسية ',
'lang' =>' English',
'langval' =>'en',

];
?>
