<?php
return[
    'lang'=>'ar',
    'lang2'=>'ar',
  'langval'=>'English',
    'sub'=>'متابعه'
];