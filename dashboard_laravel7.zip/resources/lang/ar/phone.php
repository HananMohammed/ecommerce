<?php
return[
    'phone'=>'رقم التلفون',
    'allPhone'=>'جميع ارقام التلفون ',
    'addPhone'=>'أضافه رقم تلفون',
];
