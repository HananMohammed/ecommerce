<?php
return[
     'mission'=>'المهمه والرؤيه',
     'missionAr'=>'المهمه بالعربيه'  ,
     'missionEn'=>'المهمه بالانجليزيه',
     'vissionAr'=>'الرؤيه بالعربيه'  ,
     'vissionEn'=>'الرؤيه بالانجليزيه',
     'add'=>'أضافه ',
     'Update'=>'تحديث '  ,
    'missionw'=>'المهمه',
    'vision'=>'رؤيتنا',
    'value'=>'قيمتنا',
    'readmore'=>'اقرا اكثر'

];
