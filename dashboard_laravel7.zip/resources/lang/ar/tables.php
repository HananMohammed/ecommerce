<?php
return[
    'edit'=>'تعديل',
    'delete'=>'حذف',
    'createdBy'=>'أنشاء بواسطة',
    'createdTime'=>'وقت الأنشاء',
];