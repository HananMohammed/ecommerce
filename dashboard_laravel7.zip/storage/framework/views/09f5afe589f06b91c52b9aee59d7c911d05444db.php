<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('seo.seo')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('dseo.store')); ?>"  >
                                <?php echo csrf_field(); ?>
                                

                              <!--***************************title -description -keyword****************************************-->
                                <div class="form-group">
                                    <label for="title_en"><?php echo e(trans('seo.titleeng')); ?></label>
                                    <input type="text"    name="title_en" id="title_en" class="form-control" >
                                    <?php $__errorArgs = ['title_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="title_ar"><?php echo e(trans('seo.titlear')); ?></label>
                                    <input type="text"    name="title_ar" id="title_ar" class="form-control" >
                                    <?php $__errorArgs = ['title_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                    <div class="form-group">
                                        <label for="description_en	"><?php echo e(trans('seo.desceng')); ?></label>
                                        <input type="text"    name="description_en" id="description_en" class="form-control" >
                                        <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="description_ar"><?php echo e(trans('seo.descar')); ?></label>
                                        <input type="text"    name="description_ar" id="description_ar" class="form-control" >
                                        <?php $__errorArgs = ['description_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="keyword_en"><?php echo e(trans('seo.keywordeng')); ?></label>
                                        <input type="text"    name="keyword_en" id="keyword_en" class="form-control" >
                                        <?php $__errorArgs = ['keyword_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="keyword_ar"><?php echo e(trans('seo.keywordar')); ?></label>
                                        <input type="text"    name="keyword_ar" id="keyword_ar" class="form-control" >
                                        <?php $__errorArgs = ['keyword_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div  style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!--***********************end title -description -keyword********************************************-->

                                <div class="form-group">
                                    <label for="script_head"><?php echo e(trans('seo.scripthead')); ?></label>
                                    <input type="text"    name="script_head" id="script_head" class="form-control" >
                                    <?php $__errorArgs = ['script_head'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="script_footer"><?php echo e(trans('seo.scriptfooter')); ?></label>
                                    <input type="text"    name="script_footer" id="script_footer" class="form-control" >
                                    <?php $__errorArgs = ['script_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div  style="color: darkred; font-weight: bold"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('seo.addseo')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/user_admin/seo/edit.blade.php ENDPATH**/ ?>