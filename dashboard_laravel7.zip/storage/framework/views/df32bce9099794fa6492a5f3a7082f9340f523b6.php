<div class="app-main" >
    <div class="app-sidebar sidebar-shadow">
        <div class="app-header__logo">
            <div class="logo-src"></div>
            <div class="header__pane ml-auto">
                <div>
                    <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                    </button>
                </div>
            </div>
        </div>
        <div class="app-header__mobile-menu">
            <div>
                <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                </button>
            </div>
        </div>
        <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
        </div>
        <div class="scrollbar-sidebar">
            <div class="app-sidebar__inner">
                <ul class="vertical-nav-menu">
                    <li class="app-sidebar__heading"><?php echo e(trans('dashboards.title')); ?></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage.users')): ?>
                    <li>
                        <a href="#">
                            <i class="metismenu-icon fas fa-cog"></i>
                            <?php echo e(trans('dashboards.setting')); ?>

                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                        </a>
                        <ul>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.dashboard')): ?>
                            <li>
                                <a href="<?php echo e(route('register')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('dashboards.addAdmin')); ?>

                                </a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('admin.users.index')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('dashboards.removeadmin')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('author.dashboard')): ?>
                    <li>
                        <a href="#">
                            <i class="metismenu-icon fas fa-home"></i>
                            <?php echo e(trans('dashboards.homePage')); ?>

                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                        </a>
                        <ul>

                            <li>
                                <a href="<?php echo e(route('dslider.index')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('dashboards.slider')); ?>

                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('dabout.index')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('about.about')); ?>

                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('dfeatures.index')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('features.feature')); ?>

                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('dmission.index')); ?>">
                                    <i class="metismenu-icon"></i>
                                    <?php echo e(trans('mission.mission')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>
                        <li>
                            <a href="#">
                                <i class="metismenu-icon far fa-id-card"></i>
                                <?php echo e(trans('dashboards.contactUs')); ?>

                                <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('dphone.index')); ?>">
                                        <i class="metismenu-icon"></i>
                                        <?php echo e(trans('phone.addPhone')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('dmail.index')); ?>">
                                        <i class="metismenu-icon"></i>
                                        <?php echo e(trans('mail.addMail')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('dmap.index')); ?>">
                                        <i class="metismenu-icon"></i>
                                        <?php echo e(trans('map.addmap')); ?>

                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('daddress.index')); ?>">
                                        <i class="metismenu-icon"></i>
                                        <?php echo e(trans('address.addAddress')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('dsocial.index')); ?>">
                                        <i class="metismenu-icon"></i>
                                        <?php echo e(trans('social.addsocial')); ?>

                                    </a>
                                </li>
                            </ul>
                        </li>



                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('author.user')): ?>
                        <li>
                            <a href="#">
                                <i class="metismenu-icon fas fa-newspaper"></i>
                                <?php echo e(trans('project.project')); ?>

                                <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                            </a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('author.dashboard')): ?>
                                <li>
                                    <a href="<?php echo e(route('dcategory.index')); ?>">

                                        <?php echo e(trans('project.category')); ?>

                                    </a>
                                </li>
                                    <li>
                                        <a href="<?php echo e(route('dproject.index')); ?>">

                                            <?php echo e(trans('project.allproject')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.dashboard')): ?>
                                <li>
                                    <a href="<?php echo e(route('dseo.index')); ?>">

                                        <?php echo e(trans('seo.addseo')); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.dashboard')): ?>
                        <li>
                            <a href="#">
                                <i class="metismenu-icon fas fa-file-code"></i>
                                <?php echo e(trans('seo.seo')); ?>

                                <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                            </a>
                            <ul>

                                <li>
                                    <a href="<?php echo e(route('dseo.index')); ?>">

                                        <?php echo e(trans('seo.addseo')); ?>

                                    </a>
                                </li>

                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>


<?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/inc/sidebar.blade.php ENDPATH**/ ?>