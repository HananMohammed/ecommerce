<?php echo $__env->make('dashboard.layaout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/layaout/home.blade.php ENDPATH**/ ?>