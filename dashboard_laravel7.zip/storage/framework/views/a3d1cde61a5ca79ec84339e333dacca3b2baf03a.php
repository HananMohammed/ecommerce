

<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('about.UpdateAbout')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('dabout.update',[$aboutarray->id])); ?>" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                                <div class="form-group">
                                    <label for="aboutAr"><?php echo e(trans('about.aboutAr')); ?></label>
                                    <textarea type="text"    name="about_ar" id="aboutAr" class="form-control"><?php echo e($aboutarray->about_ar); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="aboutEn"><?php echo e(trans('about.aboutEn')); ?></label>
                                    <textarea type="text"    name="about_en" id="aboutEn" class="form-control"><?php echo e($aboutarray->about_en); ?></textarea>
                                </div>


                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('about.UpdateAbout')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/about/aboutedit.blade.php ENDPATH**/ ?>