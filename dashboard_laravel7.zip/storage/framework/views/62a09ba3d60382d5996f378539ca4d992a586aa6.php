

<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('mission.mission')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('dmission.update',[$missionarray->id])); ?>"  >
                                <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                                <div class="form-group">
                                    <label for="missionAr"><?php echo e(trans('mission.missionAr')); ?></label>
                                    <textarea type="text"    name="mission_ar" id="missionAr" class="form-control"><?php echo e($missionarray->mission_ar); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="missionEn"><?php echo e(trans('mission.missionEn')); ?></label>
                                    <textarea type="text"    name="mission_en" id="missionEn" class="form-control"><?php echo e($missionarray->mission_en); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="vissionAr"><?php echo e(trans('mission.vissionAr')); ?></label>
                                    <textarea type="text"    name="vission_ar" id="vissionAr" class="form-control"><?php echo e($missionarray->vission_ar); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="vissionEn"><?php echo e(trans('mission.vissionEn')); ?></label>
                                    <textarea type="text"    name="vission_en" id="vissionEn" class="form-control"><?php echo e($missionarray->vission_en); ?></textarea>
                                </div>


                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('mission.add')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/mission/missionedit.blade.php ENDPATH**/ ?>