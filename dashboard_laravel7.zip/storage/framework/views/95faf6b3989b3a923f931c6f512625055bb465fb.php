<?php $__env->startSection('content'); ?>
    <div class="app-main__outer"  >
    <div class="app-main__inner "style="padding: 30px 30px 0;flex: 1;display: block ;width: 1060px;float: left;" >
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fas fa-chart-pie  metismenu-icon">
                    </i>
                </div>
                <div><?php echo e(trans('dash.title')); ?>


                </div>
            </div>

        </div>
    </div>
        <div class="row">
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-midnight-bloom">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">

                            <div class="widget-heading"><?php echo e(trans('dash.croups')); ?><h3 class="text-center"></h3></div>

                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-arielle-smile">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading"><?php echo e(trans('dash.news')); ?><h3 class="text-center"></h3></div>

                        </div>
                        <div class="widget-content-right">
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-grow-early">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading"><?php echo e(trans('dash.subscribers')); ?>:<h3 class="text-center"></h3></div>

                        </div>
                        <div class="widget-content-right">
                             </div>
                    </div>
                </div>
            </div>
            <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-premium-dark">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading">Products Sold</div>
                            <div class="widget-subheading">Revenue streams</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-warning"><span>$14M</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-header"><?php echo e(trans('dash.subscribe')); ?>


                </div>
                <div class="table-responsive">
                    <table id="example" class="display nowrap mb-0 table table-bordered table-striped" style="width:100%">
                        <thead>
                        <tr>

                            <th><?php echo e(trans('dash.name')); ?> </th>
                            <th><?php echo e(trans('dash.mails')); ?> </th>
                            <th><?php echo e(trans('dash.role')); ?> </th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>


                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(implode(' , ' ,$user->roles()->get()->pluck('name')->toArray())); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th># </th>
                            <th><?php echo e(trans('dash.mails')); ?> </th>

                        </tr>
                        </tfoot>
                    </table>
                </div>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/home.blade.php ENDPATH**/ ?>