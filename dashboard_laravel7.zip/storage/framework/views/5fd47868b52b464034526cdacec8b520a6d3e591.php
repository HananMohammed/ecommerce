

<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">

                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('social.addsocial')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('dsocial.store')); ?>" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="link"><?php echo e(trans('social.link')); ?></label>
                                    <input type="text"   name="link" id="link" class="form-control">
                                    <?php if($errors->has('link')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('link')[0]); ?></span>
                                    <?php endif; ?>

                                </div>
                                <div class="form-group">
                                    <select name="icon" class="custom-select" required>
                                        <option value="" selected ><?php echo e(trans('social.icon')); ?></option>
                                        <?php $__currentLoopData = $soialArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($icon->id); ?>"><p><?php echo e($icon->icon); ?></p></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <?php if($errors->has('icon')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('icon')[0]); ?></span>
                                    <?php endif; ?>

                                </div>



                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('social.addsocial')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('social.allsocial')); ?></h5>
                        <div class="main-card p-5 card">
                            
                            <table id="example" class="display nowrap mb-0 table table-bordered table-striped" style="width:100%">
                                <thead>
                                <tr>


                                    <th><?php echo e(trans('social.social')); ?> </th>
                                    <th><?php echo e(trans('social.link')); ?> </th>
                                    <th><?php echo e(trans('tables.createdBy')); ?> </th>
                                    <th><?php echo e(trans('tables.createdTime')); ?> </th>
                                    <th><?php echo e(trans('tables.delete')); ?></th>


                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $sData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>


                                        <td><?php echo e($data->socailIcon->name); ?></td>
                                        <td><a href=" <?php echo e($data->link); ?>" target="_blank"><?php echo e($data->link); ?></a></td>
                                        <td><?php echo e($data->user->name); ?></td>
                                        <td><?php echo e($data->created_at); ?></td>
                                        <td> <form method="post" action="<?php echo e(route('dsocial.destroy',[$data->id])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button type="submit" class="btn btn-danger"><?php echo e(trans('tables.delete')); ?></button></form></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>

                                    <th><?php echo e(trans('social.social')); ?> </th>
                                    <th><?php echo e(trans('social.link')); ?> </th>
                                    <th><?php echo e(trans('tables.createdBy')); ?> </th>
                                    <th><?php echo e(trans('tables.createdTime')); ?> </th>
                                    <th><?php echo e(trans('tables.delete')); ?></th>

                                </tr>
                                </tfoot>
                            </table>
                            
                            
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/social/social.blade.php ENDPATH**/ ?>