Hello baby
<?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/phone.blade.php ENDPATH**/ ?>