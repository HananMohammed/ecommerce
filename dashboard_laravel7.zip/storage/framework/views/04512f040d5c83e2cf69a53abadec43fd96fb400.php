<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">

                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('phone.addphone')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('dphone.store')); ?>" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="phone"><?php echo e(trans('phone.phone')); ?></label>
                                    <input type="text"   name="phone" id="phone" class="form-control">
                                    <?php if($errors->has('phone')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('phone')[0]); ?></span>
                                    <?php endif; ?>

                                </div>



                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('phone.addPhone')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('phone.allPhone')); ?></h5>
                        <div class="main-card p-5 card">
                            
                            <table id="example" class="display nowrap mb-0 table table-bordered table-striped" style="width:100%">
                                <thead>
                                <tr>


                                    <th><?php echo e(trans('phone.phone')); ?> </th>
                                    <th><?php echo e(trans('tables.createdBy')); ?> </th>
                                    <th><?php echo e(trans('tables.createdTime')); ?> </th>
                                    <th><?php echo e(trans('tables.delete')); ?></th>


                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $phoneArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>


                                        <td><?php echo e($phone->phone); ?></td>
                                         <td><?php echo e(implode($phone->user()->pluck('name')->toArray())); ?></td>
                                         <td><?php echo e($phone->created_at); ?></td>
                                        <td> <form method="post" action="<?php echo e(route('dphone.destroy',[$phone->id])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button type="submit" class="btn btn-danger"><?php echo e(trans('tables.delete')); ?></button></form></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>

                                    <th><?php echo e(trans('phone.phone')); ?> </th>
                                    <th><?php echo e(trans('tables.createdBy')); ?> </th>
                                    <th><?php echo e(trans('tables.createdTime')); ?> </th>
                                    <th><?php echo e(trans('tables.delete')); ?></th>

                                </tr>
                                </tfoot>
                            </table>
                            
                            
                            
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/phone/phone.blade.php ENDPATH**/ ?>