<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">

                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('project.addproject')); ?></h5>
                        <div class="main-card p-5 card">

                            <form method="post" action="<?php echo e(route('dcategory.store')); ?>" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="name_en"><?php echo e(trans('project.name_en')); ?></label>
                                    <input type="text"   name="name_en"   value="<?php echo e(old('name_en')); ?>" id="name_en" class="form-control">
                                    <?php if($errors->has('name_en')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('name_en')[0]); ?></span>
                                    <?php endif; ?>

                                </div>
                                <div class="form-group">
                                    <label for="name_ar"><?php echo e(trans('project.name_ar')); ?></label>
                                    <input type="text"   name="name_ar"   value="<?php echo e(old('name_ar')); ?>" id="name_ar" class="form-control">
                                    <?php if($errors->has('name_ar')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('name_ar')[0]); ?></span>
                                    <?php endif; ?>

                                </div>

                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('project.addproject')); ?></button>

                            </form>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/author_admin/category/edit.blade.php ENDPATH**/ ?>