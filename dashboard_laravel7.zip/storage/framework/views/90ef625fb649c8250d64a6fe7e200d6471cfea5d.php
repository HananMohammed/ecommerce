<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="row">
                <br>
                <div class="col-md-12">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(trans('dashboards.emailuser')); ?></h5>
                        <div class="main-card p-5 card">
                            <form method="post" action="<?php echo e(route('demailusers.store')); ?>"  >
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="ind_to"><?php echo e(trans('mail.indvTo')); ?></label>
                                    <input type="email"   name="ind_to" value="<?php echo e(old('ind_to')); ?>" id="ind_to" class="form-control" placeholder="mail@domin.com">
                                    <?php if($errors->has('ind_to')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('ind_to')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="ind_cc"><?php echo e(trans('mail.indvCC')); ?></label>
                                    <input type="text"   name="ind_cc" value="<?php echo e(old('ind_cc')); ?>" id="ind_cc" class="form-control" placeholder="'mail1@domin.com','mail1@domin.com',...">
                                    <?php if($errors->has('ind_cc')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('ind_cc')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <hr>

                                <div class="form-group">
                                    <label for="com_to"><?php echo e(trans('mail.comTo')); ?></label>
                                    <input type="email"   name="com_to" value="<?php echo e(old('com_to')); ?>" id="com_to" class="form-control" placeholder="mail@domin.com">
                                    <?php if($errors->has('com_to')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('com_to')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="com_cc"><?php echo e(trans('mail.comCC')); ?></label>
                                    <input type="text"   name="com_cc" value="<?php echo e(old('com_cc')); ?>" id="com_cc" class="form-control" placeholder="'mail1@domin.com','mail1@domin.com',...">
                                    <?php if($errors->has('com_cc')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('com_cc')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <hr>
                                
                                <div class="form-group">
                                    <label for="gov_to"><?php echo e(trans('mail.govTo')); ?></label>
                                    <input type="email"   name="gov_to" value="<?php echo e(old('gov_to')); ?>" id="gov_to" class="form-control" placeholder="mail@domin.com">
                                    <?php if($errors->has('gov_to')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('gov_to')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="gov_cc"><?php echo e(trans('mail.govCC')); ?></label>
                                    <input type="text"   name="gov_cc" value="<?php echo e(old('gov_cc')); ?>" id="gov_cc" class="form-control" placeholder="'mail1@domin.com','mail1@domin.com',...">
                                    <?php if($errors->has('gov_cc')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('gov_cc')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <hr>
                                
                                <div class="form-group">
                                    <label for="nind_to"><?php echo e(trans('mail.nindTo')); ?></label>
                                    <input type="email"   name="nind_to" value="<?php echo e(old('nind_to')); ?>" id="nind_to" class="form-control" placeholder="mail@domin.com">
                                    <?php if($errors->has('nind_to')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('nind_to')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="nind_cc"><?php echo e(trans('mail.nindCC')); ?></label>
                                    <input type="text"   name="nind_cc" value="<?php echo e(old('nind_to')); ?>" id="nind_cc" class="form-control" placeholder="'mail1@domin.com','mail1@domin.com',...">
                                    <?php if($errors->has('nind_cc')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('nind_cc')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <hr>
                                
                                <div class="form-group">
                                    <label for="cont_to"><?php echo e(trans('mail.conTo')); ?></label>
                                    <input type="email"   name="cont_to" value="<?php echo e(old('cont_to')); ?>" id="cont_to" class="form-control" placeholder="mail@domin.com">
                                    <?php if($errors->has('cont_to')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('cont_to')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="cont_cc"><?php echo e(trans('mail.conCC')); ?></label>
                                    <input type="text"   name="cont_cc" value="<?php echo e(old('cont_cc')); ?>" id="cont_cc" class="form-control" placeholder="'mail1@domin.com','mail1@domin.com',...">
                                    <?php if($errors->has('cont_cc')): ?>
                                        
                                        <span class="error"><?php echo e($errors->get('cont_cc')[0]); ?></span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <hr>


                                <br>
                                <button class="btn btn-success" type="submit"><?php echo e(trans('dashboards.emailuser')); ?></button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layaout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard_laravel7\resources\views/dashboard/dashboardpages/admin/emailUser/edit.blade.php ENDPATH**/ ?>